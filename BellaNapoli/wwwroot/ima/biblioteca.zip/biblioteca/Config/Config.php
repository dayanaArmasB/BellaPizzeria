<?php
const base_url = "http://localhost/biblioteca/";
const host = "localhost: 3306";
const user = "root";
const pass = "";
const db = "biblioteca";
const charset = "charset=utf8";
?>